A Pen created at CodePen.io. You can find this one at https://codepen.io/aecend/pen/JoLzqr.

 Glass-like login form with CSS3 flickering effect. Click submit button to toggle between valid and invalid states.